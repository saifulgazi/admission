<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRegistersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('student_name');
            $table->string('father_name');
            $table->string('mother_name');
            $table->string('mobile');
            $table->string('address');
            $table->string('gender');
            $table->string('religion');
            $table->string('nid');
            $table->string('year');
            $table->string('course_name');
            $table->string('batch');
            $table->string('std_id');
            $table->string('course_fee');
            $table->string('due');
            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registers');
    }
}
