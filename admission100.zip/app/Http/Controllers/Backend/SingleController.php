<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Register;
use DB;

class SingleController extends Controller
{
    public function registersingleview($id){
           $student_name = Register::find($id)->student_name;
            $father_name = Register::find($id)->father_name;
            $mother_name = Register::find($id)->mother_name;
            $mobile = Register::find($id)->mobile;
            $address = Register::find($id)->address;
            $gender = Register::find($id)->gender;
            $religion = Register::find($id)->religion;
            $nid = Register::find($id)->nid;
            $year = Register::find($id)->year;
            $course_name = Register::find($id)->course_name;
            $batch = Register::find($id)->batch;
            $std_id = Register::find($id)->std_id;
            $discount = Register::find($id)->discount;
            $course_fee = Register::find($id)->course_fee;
            $due = Register::find($id)->due;
            $installment = Register::find($id)->installment;
         return view('backend.register.view-singleregister',compact('student_name','father_name','mother_name','mobile','address','gender','religion','nid','year','course_name','batch','std_id','discount','course_fee','due','installment'));
    }
}