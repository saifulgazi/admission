<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Course;

class CourseController extends Controller
{
  public function courseview(){
    	$data['allData'] = Course::all();
    	 return view('backend.course.view-course',$data);
    }

    public function courseadd(){
    	 	return view('backend.course.add-course');
    	 }

    	 public function coursestore(Request $request){
         $this->validate($request,[
           'course' => 'required|unique:courses,course',
         ]);
    	 		$data = new Course();
    	 		$data->course = $request->course;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('course.view')->with('success', 'Data Inserted successfully');

    	 }

    	 public function courseedit($id){
    	 	$editData = Course::find($id);
    	 	return view('backend.course.edit-course',compact('editData'));
    	 }

    	 public function courseupdate(Request $request, $id){
         $this->validate($request,[
           'course' => 'required|unique:courses,course',
         ]);
    	 		$data = Course::find($id);
    	 		$data->course = $request->course;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('course.view')->with('success', 'Data updated successfully');
    	 }

    	public function coursedelete($id){
    			$conservice = Course::find($id);
    			$conservice->delete();
    			return redirect()->route('course.view')->with('success', 'Data Deleted successfully');
    	}
}
