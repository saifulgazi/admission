<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    public function usersview(){

    	$data['allData'] = User::all();
    	 return view('backend.user.view-user',$data);
    }

    public function usersadd(){
    	 	return view('backend.user.add-user');
    	 }

    	 public function usersstore(Request $request){
    	 		$this->validate($request,[
    	 			'name' => 'required',
    	 			'email' => 'required|unique:users,email',
    	 		]);
    	 		$data = new User();
    	 		$data->usertype = $request->usertype;
    	 		$data->name = $request->name;
    	 		$data->email = $request->email;
    	 		$data->password = bcrypt($request->password);
    	 		$data->save();
    	 		return redirect()->route('users.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function usersedit($id){
    	 	$editData = User::find($id);
    	 	return view('backend.user.edit-user',compact('editData'));
    	 }

    	 public function usersupdate(Request $request, $id){
    	 		$data = User::find($id);
    	 		$data->usertype = $request->usertype;
    	 		$data->name = $request->name;
    	 		$data->email = $request->email;
    	 		$data->save();
    	 		return redirect()->route('users.view')->with('success', 'Data updated successfully');
    	 }

    	public function usersdelete($id){
    			$user = User::find($id);
    			$user->delete();
    			return redirect()->route('users.view')->with('success', 'Data Deleted successfully');
    	} 
}
