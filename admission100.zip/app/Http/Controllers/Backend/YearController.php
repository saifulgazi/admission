<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Course;
use App\Model\Year;
use DB;

class YearController extends Controller
{
  public function yearview(){
      $data['allData'] = Year::all();
       return view('backend.year.view-year',$data);
    }

    public function yearadd(){
        return view('backend.year.add-year');
       }

       public function yearstore(Request $request){
         $this->validate($request,[
           'name' => 'required|unique:years,name',
         ]);
          $data = new Year();
          $data->name = $request->name;
          $data->save();
          return redirect()->route('year.view')->with('success', 'Data Inserted successfully');

       }

       public function yearedit($id){
        $editData = Year::find($id);
        return view('backend.year.edit-year',compact('editData'));
       }

       public function yearupdate(Request $request, $id){
          $data = Year::find($id);
          $this->validate($request,[
            'name' => 'required|unique:years,name',
          ]);
          $data->name = $request->name;
          $data->save();
          return redirect()->route('year.view')->with('success', 'Data updated successfully');
       }
}
