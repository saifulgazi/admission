<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $search =  $request->input('q');
        if($search!=""){
            $users = Register::where(function ($query) use ($search){
                $query->where('student_name', 'like', '%'.$search.'%')
                    ->orWhere('mobile', 'like', '%'.$search.'%');
                    ->orWhere('address', 'like', '%'.$search.'%');
                    ->orWhere('nid', 'like', '%'.$search.'%');
                    ->orWhere('course_name', 'like', '%'.$search.'%');
                    ->orWhere('std_id', 'like', '%'.$search.'%');
            })



            ->paginate(2);
            $users->appends(['q' => $search]);
        }
        else{
            $users = Register::paginate(2);
        }
        return View('backend.register.view-register')->with('allData',$users);
        //
    }
}
