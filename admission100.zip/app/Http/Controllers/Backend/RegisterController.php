<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Register;
use App\Model\Year;
use App\Model\Course;
use DB;
use PDF;

class RegisterController extends Controller
{
    public function registerview(){ 	
    	$allData = Register::all();

    	 return view('backend.register.view-register',compact('allData'));
    }


// $allData = Communicate::orderBy('id','desc')->get();
//            return view('backend.contact.view-communicate',compact('allData'));



    public function registeradd(){
            $allData = Register::all();
    	 	return view('backend.register.add-register',compact('allData'));
    	 }

    	 public function registerstore(Request $request){
    	 		$this->validate($request,[
    	 			'student_name' => 'required',
    	 			'father_name' => 'required',
    	 			'mother_name' => 'required',
    	 			'mobile' => 'required|unique:registers',
    	 			'address' => 'required',
    	 			'gender' => 'required',
    	 			'religion' => 'required',
                    'nid' => 'required|numeric|unique:registers',
    	 			'year' => 'required|numeric',
    	 			'course_name' => 'required',
    	 			'batch' => 'required',
    	 			'std_id' => 'required|numeric|unique:registers',
    	 			'course_fee' => 'required',
    	 			'due' => 'required',
    	 		]);    	 		
    	 		$data = new Register();
    	 		$data->student_name = $request->student_name;
    	 		$data->father_name = $request->father_name;
    	 		$data->mother_name = $request->mother_name;
    	 		$data->mobile = $request->mobile;
    	 		$data->address = $request->address;
    	 		$data->gender = $request->gender;
    	 		$data->religion = $request->religion;
    	 		$data->nid = $request->nid;
    	 		$data->year = $request->year;
    	 		$data->course_name = $request->course_name;
    	 		$data->batch = $request->batch;
    	 		$data->std_id = $request->std_id;
    	 		$data->course_fee = $request->course_fee;
    	 		$data->due = $request->due;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		// return redirect()->route('register.view')->with('success', 'Data Inserted successfully'); 
                return back()->with('success', 'Data Inserted successfully');

    	 }

    	 public function registeredit($id){
    	 	$editData = Register::find($id);
    	 	return view('backend.register.edit-register',compact('editData'));
    	 }

    	 public function registerupdate(Request $request, $id){
    	 		$data = Register::find($id);
    	 		$data->student_name = $request->student_name;
    	 		$data->father_name = $request->father_name;
    	 		$data->mother_name = $request->mother_name;
    	 		$data->mobile = $request->mobile;
    	 		$data->address = $request->address;
    	 		$data->gender = $request->gender;
    	 		$data->religion = $request->religion;
    	 		$data->nid = $request->nid;
    	 		$data->year = $request->year;
    	 		$data->course_name = $request->course_name;
    	 		$data->batch = $request->batch;
    	 		$data->std_id = $request->std_id;
    	 		$data->course_fee = $request->course_fee;
    	 		$data->due = $request->due;  	 		
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('register.view')->with('success', 'Data updated successfully');
    	 }

    	public function registerdelete($id){
    			$register= Register::find($id);
    			$register->delete();
    			return redirect()->route('register.view')->with('success', 'Data Deleted successfully');
    	}

        public function registerdetails($id){
            // $data = [
            // 'foo' => 'bar'
            // ];
            // $data = $id;
            $student_name = Register::find($id)->student_name;
            $father_name = Register::find($id)->father_name;
            $mother_name = Register::find($id)->mother_name;
            $mobile = Register::find($id)->mobile;
            $address = Register::find($id)->address;
            $gender = Register::find($id)->gender;
            $religion = Register::find($id)->religion;
            $nid = Register::find($id)->nid;
            $year = Register::find($id)->year;
            $course_name = Register::find($id)->course_name;
            $batch = Register::find($id)->batch;
            $std_id = Register::find($id)->std_id;
            $course_fee = Register::find($id)->course_fee;
            $due = Register::find($id)->due;
            $pdf = PDF::loadView('backend.register.student_details', compact('student_name','father_name','mother_name','mobile','address','gender','religion','nid','year','course_name','batch','std_id','course_fee','due'));
            $pdf->SetProtection(['copy', 'print'], '', 'pass');
            return $pdf->stream('document.pdf');
        }

        public function invoicedetails($id){
            // $data = [
            // 'foo' => 'bar'
            // ];
            // $data = $id;
            $student_name = Register::find($id)->student_name;
            $father_name = Register::find($id)->father_name;
            $mother_name = Register::find($id)->mother_name;
            $mobile = Register::find($id)->mobile;
            $address = Register::find($id)->address;
            $gender = Register::find($id)->gender;
            $religion = Register::find($id)->religion;
            $nid = Register::find($id)->nid;
            $year = Register::find($id)->year;
            $course_name = Register::find($id)->course_name;
            $batch = Register::find($id)->batch;
            $std_id = Register::find($id)->std_id;
            $course_fee = Register::find($id)->course_fee;
            $due = Register::find($id)->due;
            $pdf = PDF::loadView('backend.register.office_details', compact('student_name','father_name','mother_name','mobile','address','gender','religion','nid','year','course_name','batch','std_id','course_fee','due'));
            $pdf->SetProtection(['copy', 'print'], '', 'pass');
            return $pdf->stream('document.pdf');
        }





}
