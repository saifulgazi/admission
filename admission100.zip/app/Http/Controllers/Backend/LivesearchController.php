<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class LivesearchController extends Controller
{
    // function registerview()
    // {
    //  return view('backend.register.view-register');
    // }

    // function action(Request $request)
    // {
    //  if($request->ajax())
    //  {
    //   $output = '';
    //   $query = $request->get('query');
    //   if($query != '')
    //   {
    //    $data = DB::table('registers')
    //      ->where('student_name', 'like', '%'.$query.'%')
    //      ->orwhere('mobile', 'like', '%'.$query.'%')
    //      ->orWhere('address', 'like', '%'.$query.'%')
    //      ->orWhere('nid', 'like', '%'.$query.'%')
    //      ->orWhere('course_name', 'like', '%'.$query.'%')
    //      ->orWhere('std_id', 'like', '%'.$query.'%')
    //      ->orderBy('id', 'DESC')
    //      ->get();
    //      ->paginate(3);

    //   }
    //   else
    //   {
    //    $data = DB::table('registers')
    //      ->orderBy('id', 'desc')
    //      ->get();
    //   }
    //   $total_row = $data->count();
    //   $asset = asset('upload/register_images/');
    //   if($total_row > 0)
    //   {
    //    foreach($data as $key => $row)
    //    {
    //     //  $edit = route('register.edit',$row->id);
    //     $output .= '
    //     <tr>
    //      <td>'.++$key.'</td>
    //        <td>'.$row->student_name.'</td>
    //        <td>'.$row->father_name.'</td>
    //        <td>'.$row->mother_name.'</td>
    //        <td>'.$row->mobile.'</td>
    //        <td>'.$row->address.'</td>
    //        <td>'.$row->gender.'</td>
    //        <td>'.$row->religion.'</td>
    //        <td>'.$row->nid.'</td>
    //        <td>'.$row->year.'</td>
    //        <td>'.$row->course_name.'</td>
    //        <td>'.$row->batch.'</td>
    //       <td>'.$row->std_id.'</td>
    //        <td>'.$row->course_fee.'</td>
    //        <td>'.$row->due.'</td>
    //        <td>
    //        <a  class="btn btn-sm btn-primary" href="'.route('register.edit',$row->id).'"><i class="fa fa-edit"></i>Edit</a>
    //       @if(Auth::user()->usertype=='Admin')
    //        <a  class="btn btn-sm btn-danger" href="'.route('register.delete',$row->id).'"><i class="fa fa-edit"></i>Delete</a>
    //       @endif
    //        <a  class="btn btn-sm btn-info" href="'.route('invoice.details',$row->id).'"><i class="fa fa-eye"></i>Details</a>
    //        <a  class="btn btn-sm btn-success" href="'.route('register.singleview',$row->id).'"><i class="fa fa-eye"></i>View</a>
    //        </td>
           
    //     </tr>
    //     ';
    //    }
    //   }
    //   else
    //   {
    //    $output = '
    //    <tr>
    //     <td align="center" colspan="5">No Data Found</td>
    //    </tr>
    //    ';
    //   }
    //   $data = array(
    //    'table_data'  => $output,
    //    'total_data'  => $total_row
    //   );

    //   echo json_encode($data);
    //  }
    // }
}
